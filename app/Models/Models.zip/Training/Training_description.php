<?php

namespace App\Models\Training;

use Illuminate\Database\Eloquent\Model;

class Training_description extends Model
{
    //
}
