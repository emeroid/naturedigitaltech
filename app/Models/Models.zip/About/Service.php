<?php

namespace App\Models\About;

use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    //
}
