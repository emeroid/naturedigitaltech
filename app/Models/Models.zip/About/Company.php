<?php

namespace App\Models\About;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    //
}
