<?php

namespace App\Models\Jobs;

use Illuminate\Database\Eloquent\Model;

class AboutJob extends Model
{
    //
}
