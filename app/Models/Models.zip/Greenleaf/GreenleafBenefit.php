<?php

namespace App\Models\Greenleaf;

use Illuminate\Database\Eloquent\Model;

class GreenleafBenefit extends Model
{
    //
}
