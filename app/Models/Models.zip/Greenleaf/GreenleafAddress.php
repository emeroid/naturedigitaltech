<?php

namespace App\Models\Greenleaf;

use Illuminate\Database\Eloquent\Model;

class GreenleafAddress extends Model
{
    //
}
