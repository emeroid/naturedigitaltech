<?php

namespace App\Models\Affiliate;

use Illuminate\Database\Eloquent\Model;

class Affiliate_description extends Model
{
    //
}
