<?php

namespace App\Models\Term;

use Illuminate\Database\Eloquent\Model;

class Terms extends Model
{
    //
}
