<?php

namespace App\Http\Controllers;

use App\Models\Greenleaf\GreenleafAddress;
use Illuminate\Http\Request;

class GreenleafAddressController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Greenleaf\GreenleafAddress  $greenleafAddress
     * @return \Illuminate\Http\Response
     */
    public function show(GreenleafAddress $greenleafAddress)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Greenleaf\GreenleafAddress  $greenleafAddress
     * @return \Illuminate\Http\Response
     */
    public function edit(GreenleafAddress $greenleafAddress)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Greenleaf\GreenleafAddress  $greenleafAddress
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, GreenleafAddress $greenleafAddress)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Greenleaf\GreenleafAddress  $greenleafAddress
     * @return \Illuminate\Http\Response
     */
    public function destroy(GreenleafAddress $greenleafAddress)
    {
        //
    }
}
