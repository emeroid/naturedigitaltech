INSERT INTO `slides` (`id`, `category`, `body`, `bg_img`, `body_img`) VALUES
(1, 'Affiliate', 'Take advantage of our Affiliate Program Today!', 'transparent2.png', '1.jpg'),
(2, 'Training', 'Join our training to benefit from our courses.', 'transparent2.png', '4.jpg'),
(3, 'Job', 'We are now hiring skilled workers.', 'transparent2.png', '2.jpg'),
(4, '', 'Request for a technician / skill man on solar installer, CCTV installer, electrician,DSTV installer etc.', 'transparent2.png', '6.jpg');