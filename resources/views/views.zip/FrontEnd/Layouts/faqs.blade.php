INSERT INTO `f_a_q_s` (`id`, `q`, `a`) VALUES
(1, 'Who are You and What Do You Do?', 'Nature Digital was established in 2020 by a group of partners from three different countries; China, Canada and Nigeria.


The first Digital Community for experts and professionals on Nature and Digital Technologies and those that want the training and the services of Nature and Digital Technology professionals. Our proffessional services includes Survillance Systems (CCTV) Installations, DSTV/Solar Energy Installations, Smart Phones Repair, Website Design, Digital Marketing, Beauty Services, Event and Food Services, Delivery Services, Private classes etc.

We also have online shop stocked with Quality, beautiful and affordable products. Our Products cut across technical and digital accessories, like CCTV Cameras, Solar Accessories, Fashion, electronics, groceries etc. Our delivery and administrative system is effective.


Additionally, NatureDigital has an affliate program that gives members an opportunity to earn big with our affliate commision, shop products for free with various incentives ( products like Solar Fridge, Solar Phone, Solar Generators, classic dresses, specially made Yogurt, etc) As you stick to the company as an affliate, you will grow to have more incentives, the Epic is a car worth 1.5 Million Naira.'),
(2, 'How do I register?', 'To register, simply click here and provide all necessary details. Registration is free. After you have registered, you will need to buy any product of your choice worth up to N20,000, in order to activate your account and gain access to your dashboard. This the best network marketing, you do not need to pay money for registration, once you buy a product a product you need you become a full member with access to our affliate commission and incentives'),
(3, 'What is the Affliate refund policy?', 'You did not pay any money to the company for registration or investment, hence there is nothing to refund. You are our customer and affliate, you earn commission through the introduction of friends and families to us as customers.The platform belongs to Naturedigital. The company has the prerogative to change its policies and commission but will always inform the members. We are out for the benefits of all our customers/members, therefore, the welfare of all is very imperative for us.'),
(4, 'What do I benefit?', 'You can earn a lot of cash prizes and incentives depending on your current stage per time. As your downlines keep referring other people, your matrix grows bigger till you get to the stage where you win a car worth 1.5 Million Naira. And as a member, you have access to purchasing our products at affordable prices. As a member you are close to us and can easily be employed to work with us. . You also get 2% cash back of whatever anybody buys using your user id. Please click here to view all our amazing cash rewards and incentives.'),
(5, 'Can I monetize my reward?', 'Every earnings is 100% Cash transfer to your bank account from your dashboard
'),
(6, 'What is the guarantee?', 'We are professionals with years of experience in personal sales. Apart from that our board of directors are are experienced and sincere humanitarians. Our products are the most sought after, and so our business continues as long as there is natural resources and as long as digitalization and technology exists.'),
(7, 'What is your product refund policy?', 'Goods can be returned within 1 to 2 days if UNUSED in the same Unopened Box as purchased for a full refund.

Goods returned after 2 days of purchase in Unopened Boxes only can be returned for EXCHANGE only for goods of same value. No refund will be given for any goods returned in unopened boxes after 2 days.

Used goods that have been tampered with cannot be Returned or Exchanged.

There is no Exchange, no Return or no Refund for all used Electronic goods or Components like Cameras, Inverters, Charge Controllers, Solar Panel or Stabilizers. etc.');